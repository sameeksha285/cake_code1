<?php
App::uses('AppController', 'Controller');
App::uses('WebLib', 'Lib');
App::uses('CakePlugin', 'Core');
class TimerController extends AppController {

function timelog() {
	// $weblib = new WebLib();
	// echo json_encode($weblib->myname()); exit;
}
function start_now() {

	
}
function timer_detail() {

	
}
function get_ses_id(){
         $id = SES_ID ;
        echo json_encode($id);exit;
}

}  

?>
