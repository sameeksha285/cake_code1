<?php
class EasycaseMilestone extends AppModel{
	var $name = 'EasycaseMilestone';
	
	/*var $belongsTo = array('Easycase' =>
						array('className'     => 'Easycase',
						'foreignKey'    => 'easycase_id'
						),
						'Milestone' =>
						array('className'     => 'Milestone',
						'foreignKey'    => 'milestone_id'
						)
					);*/
}
?>