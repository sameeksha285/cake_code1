<?php
class CaseComment extends AppModel{
	var $name = 'CaseComment';
}
?>