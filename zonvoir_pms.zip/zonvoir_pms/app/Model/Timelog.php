<?php
class Timelog extends AppModel{
	var $name = 'Timelog';
	function getAllTimelog($params)
	{
		$allData = $this->find('all', array('conditions'=>array('Timelog.task_id'=>$params)));
		return $allData;
	}
}
?>