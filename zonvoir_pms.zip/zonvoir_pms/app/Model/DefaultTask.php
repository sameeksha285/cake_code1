<?php
class DefaultTask extends AppModel{
	var $name = 'DefaultTask';
}
?>
