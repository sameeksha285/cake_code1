<?php
class SaveReport extends AppModel{
	var $name = 'SaveReport';
}
?>
