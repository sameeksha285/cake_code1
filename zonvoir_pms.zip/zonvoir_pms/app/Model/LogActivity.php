<?php
class LogActivity extends AppModel{
	var $name = 'LogActivity';
}
?>