<?php
class CaseSetting extends AppModel{
	var $name = 'CaseSetting';	
}
?>
