<?php
class Subscription extends AppModel{
	var $name = 'Subscription';
	
}
?>