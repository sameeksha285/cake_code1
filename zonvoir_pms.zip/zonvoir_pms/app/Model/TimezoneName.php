<?php
class TimezoneName extends AppModel{
	var $name = 'TimezoneName';
}
?>