<?php
class Timezone extends AppModel{
	var $name = 'Timezone';
}
?>