<?php
class ProjectTemplate extends AppModel{
	var $name = 'ProjectTemplate';
}
?>
