<?php
class UserNotification extends AppModel{
	var $name = 'UserNotification';
}
?>