<?php
class DefaultProjectTemplate extends AppModel{
	var $name = 'DefaultProjectTemplate';
}
?>
